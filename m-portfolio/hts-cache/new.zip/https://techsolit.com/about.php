<!doctype html>
<html lang="en">
<head>
    <title>TECHSOL</title>
    <meta charset="utf-8">
    <meta name="description" content="" />
    <meta name="Keywords" content="" />
    


<link rel="shortcut icon" type="image/x-icon" href="assets/img/techsol-fav.webp">
<!-- Place favicon.ico in the root directory -->
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- CSS here -->
<link rel="stylesheet" href="assets/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.css">
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/main.css">
<style>
    .foot-about a img,.navbar-light a.navbar-brand img {
    width: 170px;
}
.foot-about a img{
    filter:invert(1) brightness(3.5);
}
</style>

</head>
<body class="aboutpage inner-page">


<header id="header-outer">
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container">
            <a class="navbar-brand" href="/">
                <img src="assets/img/logo-techsol.webp" alt="logo">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
              <ul class="navbar-nav main-nav mb-2 mb-lg-0">
                  <li class="nav-item"><a href="/" class="nav-link ">Home</a></li>
                  <li class="nav-item"><a href="/about" class="nav-link active">About</a></li>
                  <li class="nav-item service-menu dropdown">
                    <a href="javascript:;" class="nav-link dropdown-toggle " id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">Services</a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item " href="dissertation">Dissertation</a></li>
                        <li><a class="dropdown-item "  href="essay">Essay</a></li>
                        <li><a class="dropdown-item " href="assignment">Assignment</a></li>
                        <li><a class="dropdown-item " href="thesis">Thesis</a></li>
                    </ul>
                  </li>
                  <li class="nav-item"><a href="/e-book" class="nav-link ">E-Book</a></li>
                  <li class="nav-item"><a href="/packages" class="nav-link ">Packages</a></li>
                  <li class="nav-item"><a href="/portfolio" class="nav-link ">Portfolio</a></li>
                  <li class="nav-item"><a href="/testimonials" class="nav-link ">Testimonials</a></li>
              </ul>
              <ul class="navbar-nav cnt-info">
                <li class="nav-item"><a href="/contact-us" class="theme-btn">Contact Now</a></li>
              </ul>
            </div>
            <!-- mega service menu -->
            <div class="service-dropdown dropdown-sec" style="display:none;">
                <div class="row service-box justify-content-center">
                    <div class="col-lg-3 web">
                        <a href="/services/web-design" class="service-type-box">
                            <img alt="img" src="assets/img/icons/web.png" class="service-icon">
                            <h2>Web <span class="clr-yellow">Design </span> & <br> Development</h2>
                            <p>Are you looking for a website with interactive graphics</p>
                        </a>
                    </div>
                    <div class="col-lg-3 logo">
                        <a href="/services/logo-design" class="service-type-box">
                            <img alt="img" src="assets/img/icons/logo.png" class="service-icon">
                            <h2>Logo <span class="clr-yellow">Design </span></h2>
                            <p>Are you looking for logo designs to stand out from your completion?</p>
                        </a>
                    </div>
                    <div class="col-lg-3 ecom">
                        <a href="/services/ecommerce" class="service-type-box">
                            <img alt="img" src="assets/img/icons/ecom.png" class="service-icon">
                            <h2>E-Commerce</h2>
                            <p>Are you willing to build your online store?</p>
                        </a>
                    </div>
                    <div class="col-lg-3 seo">
                        <a href="/services/seo" class="service-type-box">
                            <img alt="img" src="assets/img/icons/seo.png" class="service-icon">
                            <h2>SEO</h2>
                            <p>Are you desperate to boost organic traffic on your website? </p>
                        </a>
                    </div>
                    <div class="col-lg-3 smm">
                        <a href="/services/smm" class="service-type-box">
                            <img alt="img" src="assets/img/icons/smm.png" class="service-icon">
                            <h2>SMM</h2>
                            <p>Are you waiting to go viral on social media? </p>
                        </a>
                    </div>
                    <div class="col-lg-3 video">
                        <a href="/services/animation" class="service-type-box">
                            <img alt="img" src="assets/img/icons/video.png" class="service-icon">
                            <h2>Video <span class="clr-yellow">Animation</span></h2>
                            <p>Are you excited to bring your ideas to virtual reality? </p>
                        </a>
                    </div>
                    <div class="col-lg-3 video">
                        <a href="/services/animation" class="service-type-box">
                            <img alt="img" src="assets/img/icons/video.png" class="service-icon">
                            <h2>Video <span class="clr-yellow">Book Writing</span></h2>
                            <p>Are you excited to bring your ideas to virtual reality? </p>
                        </a>
                    </div>
                    <div class="col-lg-3 video">
                        <a href="/services/animation" class="service-type-box">
                            <img alt="img" src="assets/img/icons/video.png" class="service-icon">
                            <h2>Video <span class="clr-yellow">Copywriting</span></h2>
                            <p>Are you excited to bring your ideas to virtual reality? </p>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </nav>
</header><section class="banner-home bg_blue">
    <div class="container text-white">
        <div class="row banner-top align-items-center">
            <div class="col-lg-7 banner-content">
                <span class="sub-hd" >Years of Expertise in The Business</span>
                <h1 class="theme-hd" ><span class="bold">Get to Know  </span>Us Better </h1>
                <p  >For clients all around the world, TECHSOL is a top provider of web development, software development, e-commerce, and design solutions. Our Management of professionals give great performance and go above and beyond your expectations, whether you need unique web, software, or0 design solutions. We achieve this through open communication, creativity, timely delivery, consistency, and a dedication to your company's success. Our clients can boost earnings and outperform the competition thanks to the flexible, affordable, and personalised content management solutions we offer. We can give you all the answers you require for the success of your business thanks to our years of consultation and maintenance experience.</p>
            </div>
        </div>
    </div>
    <div class="right-top"><img src="assets/img/about-back.webp" alt="about-img"></div>
</section>
<section class="counter-sec">
    <div class="container">
        <div class="counter-area">
            <div class="counter-content bg-pink ">
                <h2><div class="stat-number" data-n="35"><span class="Single">36.5</span>k+</div></h2>
                <span>Happy Clients </span>
            </div>
            <div class="counter-content bg-green ">
                <h2><div class="stat-number" data-n="35"><span class="Single">36</span>k+</div></h2>
                <span>Projects Delivered </span>
            </div>
            <div class="counter-content bg-blue">
                <h2><div class="stat-number" data-n="35"><span class="Single">423</span>+</div></h2>
                <span>Team Players </span>
            </div>
            <div class="counter-content bg-pink">
                <h2><div class="stat-number" data-n="35"><span class="Single">23</span>+</div></h2>
                <span>Excellence Awards</span>
            </div>
        </div>
    </div>
</section>
<section class="about">
    <div class="container">
    <div class="row align-items-center">
        <div class="col-lg-6">
            <div class="scene2" id="scene1">
                <div class="layer2" data-depth='0.3'><img src="assets/img/about-img01.webp" alt="img02"></div>
            </div>
        </div>
        <div class="col-lg-6 about-content">
            <span class="sub-hd">More about Techsol</span>
            <h2 class="theme-hd">About Us</h2>
            <p>The business, which has more than 10 years of expertise, has come a long way since it was founded, conquering many obstacles and winning many awards and honors. Our ability to address the needs of clients and candidates whose demands go beyond local markets is made possible by the team. Our onshore staff gives us perspective into international business and possibilities, while our strong local foundations give us valuable insights into industry and culture. </p>
            <ul class="about-list">
                <li>
                    <span class="list-info">
                        <span class="title">Boosting the Organization: </span>
                        <span class="desc">Hiring the most polished and skilled individuals to help put the work satisfaction of the company at higher values with our clients, and making sure we meet every demand our client requires.</span>
                    </span>
                </li>
                <li>
                    <span class="list-info">
                        <span class="title">Satisfied Clients</span>
                        <span class="desc">A number of satisfied clients that prove our consistency and dedication towards them. We believe in creating cordial and long term relationships with our clients. </span>
                    </span>
                </li>
                <li>
                    <span class="list-info">
                        <span class="title">Projects Delivered</span>
                        <span class="desc">We have completed tens of thousands of projects to date, and our established portfolio and client list of major corporations attest to the caliber of the work we produce.</span>
                    </span>
                </li>
            </ul>
        </div>
    </div>
</div>
</section>
<section class="process-sec">
        <div class="container-fluid">
        <div class="row align-items-center">
            <div class="col-lg-7 lf-side">
                <div class="theme-content">
                    <span class="sub-hd">How Does All This Works?</span>
                    <h2 class="theme-hd">What We Work for</h2>
                    <p>The foundations of your success is our coordinated communication and effective project management. To produce the greatest results and flawless service for our clients, we set and follow by deadlines. You will first speak with one of our knowledgeable project managers when you have a project in mind, and they will assign the right team of developers to work on it. Our committed developers are hand-selected, trained, and ready to work whenever you need them. You will always have access to daily reports, reports that are well-organized, and a channel of communication with your development team. </p>
                </div>
                <div class="row">
                    <div class="col-lg-4">
                        <div class="icon-box">
                            <img src="assets/img/technical-suppo.webp" alt="icon01">
                            <span class="title">Create</span>
                            <p>We believe in being good at creating. Dedicated workers do their best work, with following deadlines.</p>
                            <a href="#" class="theme-btn">Read More <i class="fa fa-plus"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="icon-box">
                            <img src="assets/img/analyzing.webp" alt="icon02">
                            <span class="title">Analyze </span>
                            <p>Our development team here work on every little detail and analyses it too, so the work goes around smoothly.</p>
                            <a href="#" class="theme-btn">Read More <i class="fa fa-plus"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="icon-box">
                            <img src="assets/img/camera-dolly.webp" alt="icon03">
                            <span class="title">Deliver </span>
                            <p>You will have access to all the work, regarding your work, you will be delivered with the best work with everything you want it to be.</p>
                            <a href="#" class="theme-btn">Read More <i class="fa fa-plus"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-5 rt-side">
                <img src="assets/img/men-img.webp" alt="lf-img">
            </div>
        </div>
    </div>
    </section>

<section class="about our-vision">
    <div class="container">
    <div class="row align-items-center">
        <div class="col-lg-6 about-content">
            <span class="sub-hd">What are we Working Towards?</span>
            <h2 class="theme-hd">The Vision</h2>
            <p>A group of professionals in management, strategy, content creation, design, and development make up TECHSOL. We all have individual visions and goals, and we work hard to achieve them so that those who turn to us for IT needs will have faith in us. We consistently explore new opportunities in the field of web development and make the most of technology and knowledge to build solutions for our clients, business partners, and experts in the field.</p>
            <ul class="about-list">
                <li>
                    <span class="list-info">
                        <span class="title">Boosting the Organization: </span>
                        <span class="desc"> Hiring the most polished and skilled individuals to help put the work satisfaction of the company at higher values with our clients, and making sure we meet every demand our client requires. </span>
                    </span>
                </li>
                <li>
                    <span class="list-info">
                        <span class="title">More than 100k online courses are available: </span>
                        <span class="desc">We offer more than 100k online courses at our company to choose from, variety of courses that you can get your career started with. </span>
                    </span>
                </li>
                <li>
                    <span class="list-info">
                        <span class="title">Learn the newest skill:</span>
                        <span class="desc">Learn the newest skills with us so you can get better at your career and professional life.</span>
                    </span>
                </li>
            </ul>
        </div>
        <div class="col-lg-6">
            <div class="scene2" id="scene1">
                <div class="layer2" data-depth='0.3'><img src="assets/img/about-img01.webp" alt="img02"></div>
            </div>
        </div>
    </div>
</div>
</section>
<section class="tesimonials">
        <div class="container">
        <div class="theme-content text-center">
            <h2 class="theme-hd">What our Clients Say</h2>
            <p>Take a look at what our valuable clients have to say about us  </p>
        </div>
    </div>
    <div class="reviews-area">
        <div class="review-item">
            <div class="review-content">
                <img src="assets/img/img01.webp" alt="review01">
                <span class="title">Britney Mayers</span>
                <p>I contacted TechSol for a website which I knew nothing about. Not only did they help me with my website but they also gave great business advice and helped me promote my business. This service is highly recommended</p>
            </div>
        </div>
        <div class="review-item">
            <div class="review-content">
                <img src="assets/img/img02.webp" alt="review01">
                <span class="title">Ben Flinn</span>
                <p>I was impressed by TechSols professional staff. They performed great SEO on my website and successfully helped it reach the top ten of Google. Not only were they consistent but kept me updated all along.</p>
            </div>
        </div>
        <div class="review-item">
            <div class="review-content">
                <img src="assets/img/img03.webp" alt="review01">
                <span class="title">Philip Lincon</span>
                <p>Thank you for making my journey and brand launch possible with creative ideas and a unique brand identity that I could only hope for a couple of months earlier. I am truly thankful. </p>
            </div>
        </div>
        <div class="review-item">
            <div class="review-content">
                <img src="assets/img/img04.webp" alt="review01">
                <span class="title">Jenna Maxwell </span>
                <p>We have been struggling to get a good online presence and our old website was seriously outdated. Hatsoff to TechSol for pitching such great ideas and providing us with an interactive website which can stay relevant for the next ten years as well. </p>
            </div>
        </div>
    </div>
    </section>
<footer class="bg-blue footer-outer">
    <div class="footer-top">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 foot-about">
                    <a href="/"><img src="assets/img/logo-techsol.webp" alt="footer-logo"></a>
                    <p>Hire Professionals to do all the work for you while you can just enjoy the perks of having a team working for you at all times with their bests staff at work to deliver you all that you need them to do for you. </p>
                    <ul class="foot-info">
                        <li><a href="mailto:info@techsolit.com"> info@techsolit.com                         </a></li>
                        <li><a href="tel:+12345678901">  +12345678901</a></li>
                        <li><a href="#"> your text goes here it's just a placeholder</a></li>
                      
                    </ul>
                </div>
                <div class="col-lg-3 foot-services">
                    <h4>All Services</h4>
                    <ul>
                        <li><a href="/services/web-design"> Web Design & Development</a></li>
                        <li><a href="/services/logo-design"> Logo Design</a></li>
                        <li><a href="/services/ecommerce"> Ecommerce</a></li>
                        <li><a href="/services/seo"> SEO</a></li>
                        <li><a href="/services/smm"> SMM</a></li>
                        <li><a href="/services/animation"> Video Animation</a></li>
                    </ul>
                </div>
                <div class="col-lg-3">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="/"> Home</a></li>
                        <li><a href="/about.php"> About</a></li>
                        <li><a href="/project.php"> Portfolio</a></li>
                        <li><a href="/package.php"> Packages</a></li>
                    </ul>
                </div>
                <div class="col-lg-3 p-0">
                    <h4>Contact Details</h4>
                    <form class="newsletter">
                        <div class="form-group">
                            <input class="form-control" type="email" placeholder="Enter Your Email Here" name="email">
                        </div>
                        <button type="button">Subscribe Now</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="container">
            <div class="d-flex justify-content-between">
                <p>Copyright © 2022 <a href="/">TECHSOL IT</a> All Rights Reserved. <a href="/">Privacy</a> | <a href="/">Terms of Use</a></p>
                <div class="foot-social">
                    <a href="https://www.facebook.com/designsmakers99/" target="_blank"><i class="fa fa-facebook"></i></a>
                    <a href="https://www.instagram.com/designsmakers_/" target="_blank"><i class="fa fa-instagram"></i></a>
                    <a href="https://www.linkedin.com/in/designs-makers-8769b9258/" target="_blank"><i class="fa fa-linkedin"></i></a>
                    <a href="https://www.youtube.com/@designsmakers/about" target="_blank"><i class="fa fa-youtube"></i></a>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- nft-address -->
<div class="modal fade theme-popup" id="propertydetails" tabindex="-1" aria-labelledby="propertydetails" aria-modal="true" role="dialog">
  <div class="modal-dialog modal-dialog-centered text-center">
    <div class="modal-content first-step">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        <div class="first-step">
            <img src="" alt="popoup-img">
            <div class="form-group">
                <div class="d-flex justify-content-between">
                    <label class="proximab">NFT Address</label>
                    <a href="#" class="#"><i class="fa fa-plus"></i> Add More</a>
                </div>
                <input class="form-control" name="nftaddress" type="text">
            </div>
            <a class="theme-btn btn-center">Submit</a>
        </div>
        <div class="sec-step" style="display:none;">
             <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            <h2 class="text-center">Plan Is Unlcoked</h2>
            <a href="#" class="theme-btn btn-center">View Subscription</a>
        </div>
    </div>
  </div>
</div>



<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/parallax/3.1.0/parallax.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/main.js"></script></body>
</html>